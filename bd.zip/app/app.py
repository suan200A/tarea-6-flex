from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
from controller.controllerCarro import *
from controller.controllerAuth import verify_user, create_user, find_user_by_username

import os
from werkzeug.utils import secure_filename


app = Flask(__name__)
application = app
# Cambia esta clave por una segura en producción
app.secret_key = 'cambiar_por_una_clave_muy_secreta'


@app.route('/', methods=['GET', 'POST'])
def inicio():
    # Si no hay usuario en sesión, iniciar en login
    if not session.get('user'):
        return redirect(url_for('login'))
    return render_template('public/layout.html', miData=listaCarros())


@app.route('/registrar-carro', methods=['GET', 'POST'])
def addCarro():
    if not session.get('user'):
        return redirect(url_for('login'))
    return render_template('public/acciones/add.html')


@app.route('/carro', methods=['POST'])
def formAddCarro():
    if request.method == 'POST':
        marca = request.form['marca']
        modelo = request.form['modelo']
        year = request.form['year']
        color = request.form['color']
        puertas = request.form['puertas']
        favorito = request.form['favorito']

        if 'foto' in request.files and request.files['foto'].filename != '':
            file = request.files['foto']
            nuevoNombreFile = recibeFoto(file)
            resultData = registrarCarro(marca, modelo, year, color, puertas, favorito, nuevoNombreFile)
            if resultData == 1:
                return render_template('public/layout.html', miData=listaCarros(), msg='El Registro fue un éxito', tipo=1)
            else:
                return render_template('public/layout.html', msg='No se pudo registrar', tipo=1)
        else:
            return render_template('public/layout.html', msg='Debe cargar una foto', tipo=1)


@app.route('/form-update-carro/<string:id>', methods=['GET', 'POST'])
def formViewUpdate(id):
    if not session.get('user'):
        return redirect(url_for('login'))
    if request.method == 'GET':
        resultData = updateCarro(id)
        if resultData:
            return render_template('public/acciones/update.html', dataInfo=resultData)
        else:
            return render_template('public/layout.html', miData=listaCarros(), msg='No existe el carro', tipo=1)
    return render_template('public/layout.html', miData=listaCarros(), msg='Metodo HTTP incorrecto', tipo=1)


@app.route('/ver-detalles-del-carro/<int:idCarro>', methods=['GET', 'POST'])
def viewDetalleCarro(idCarro):
    if request.method == 'GET':
        resultData = detallesdelCarro(idCarro)
        if resultData:
            return render_template('public/acciones/view.html', infoCarro=resultData, msg='Detalles del Carro', tipo=1)
        else:
            return render_template('public/acciones/layout.html', msg='No existe el Carro', tipo=1)
    return redirect(url_for('inicio'))


@app.route('/actualizar-carro/<string:idCarro>', methods=['POST'])
def formActualizarCarro(idCarro):
    if request.method == 'POST':
        marca = request.form['marca']
        modelo = request.form['modelo']
        year = request.form['year']
        color = request.form['color']
        puertas = request.form['puertas']
        favorito = request.form['favorito']

        foto_carro = None
        if 'foto' in request.files and request.files['foto'].filename != '':
            file = request.files['foto']
            foto_carro = recibeFoto(file)

        resultData = recibeActualizarCarro(marca, modelo, year, color, puertas, favorito, foto_carro, idCarro)

        if resultData == 1:
            return render_template('public/layout.html', miData=listaCarros(), msg='Datos del carro actualizados', tipo=1)
        else:
            return render_template('public/layout.html', miData=listaCarros(), msg='No se pudo actualizar', tipo=1)


@app.route('/borrar-carro', methods=['GET', 'POST'])
def formViewBorrarCarro():
    if not session.get('user'):
        return jsonify([0])
    if request.method == 'POST':
        idCarro = request.form['id']
        nombreFoto = request.form['nombreFoto']
        resultData = eliminarCarro(idCarro, nombreFoto)
        if resultData == 1:
            return jsonify([1])
        else:
            return jsonify([0])


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if verify_user(username, password):
            session['user'] = username
            flash('Inicio de sesión correcto', 'success')
            # redirigir a la página principal después de login
            return redirect(url_for('inicio'))
        else:
            flash('Usuario o contraseña incorrectos', 'danger')
            return render_template('public/acciones/login.html')
    return render_template('public/acciones/login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if find_user_by_username(username):
            flash('El usuario ya existe', 'warning')
            return render_template('public/acciones/register.html')
        ok = create_user(username, password)
        if ok:
            flash('Usuario creado. Ahora inicia sesión.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Error creando usuario', 'danger')
            return render_template('public/acciones/register.html')
    return render_template('public/acciones/register.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Sesión cerrada', 'info')
    return redirect(url_for('inicio'))


def eliminarCarro(idCarro='', nombreFoto=''):
    conexion_MySQLdb = connectionBD()
    cur = conexion_MySQLdb.cursor(dictionary=True)
    cur.execute('DELETE FROM carros WHERE id=%s', (idCarro,))
    conexion_MySQLdb.commit()
    resultado_eliminar = cur.rowcount
    basepath = os.path.dirname(__file__)
    url_File = os.path.join(basepath, 'static/assets/fotos_carros', nombreFoto)
    try:
        os.remove(url_File)
    except Exception:
        pass
    return resultado_eliminar



def recibeFoto(file):
    basepath = os.path.dirname(__file__)
    filename = secure_filename(file.filename)
    extension = os.path.splitext(filename)[1]
    nuevoNombreFile = stringAleatorio() + extension
    upload_path = os.path.join(basepath, 'static/assets/fotos_carros', nuevoNombreFile)
    file.save(upload_path)
    return nuevoNombreFile



@app.errorhandler(404)
def not_found(error):
    return redirect(url_for('inicio'))


if __name__ == '__main__':
    app.run(debug=True, port=8000)