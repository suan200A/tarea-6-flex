from conexionBD import connectionBD
import hashlib


def find_user_by_username(username):
    conn = connectionBD()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT id, username, password FROM usuarios WHERE username = %s LIMIT 1", (username,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    return user


def create_user(username, password):
    # password debe llegara ya en texto plano; aquí lo hasheamos con sha256
    hashed = hashlib.sha256(password.encode('utf-8')).hexdigest()
    try:
        conn = connectionBD()
        cur = conn.cursor()
        cur.execute("INSERT INTO usuarios (username, password) VALUES (%s, %s)", (username, hashed))
        conn.commit()
        cur.close()
        conn.close()
        return True
    except Exception as e:
        print('Error creando usuario:', e)
        return False


def verify_user(username, password):
    user = find_user_by_username(username)
    if not user:
        return False
    hashed = hashlib.sha256(password.encode('utf-8')).hexdigest()
    return hashed == user.get('password')
